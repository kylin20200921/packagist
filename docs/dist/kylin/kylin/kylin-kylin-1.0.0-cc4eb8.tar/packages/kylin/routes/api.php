<?php
use Illuminate\Support\Facades\Route;

use Kylin\App\Http\Controllers\HomeController;
use Kylin\App\Http\Controllers\Payment\AlipayController;
use Kylin\App\Http\Controllers\Payment\WechatController;
use Kylin\App\Http\Controllers\Payment\UnipayController;

Route::any('/', [HomeController::class, 'index']);

Route::prefix('alipay')->group(function () {
    Route::any('web', [AlipayController::class, 'web'])->name('alipay.web');
    Route::any('wap', [AlipayController::class, 'wap'])->name('alipay.wap');
    Route::any('app', [AlipayController::class, 'app'])->name('alipay.app');
    Route::any('mini', [AlipayController::class, 'mini'])->name('alipay.mini');
    Route::any('pos', [AlipayController::class, 'pos'])->name('alipay.pos');
    Route::any('scan', [AlipayController::class, 'scan'])->name('alipay.scan');
    Route::any('transfer', [AlipayController::class, 'transfer'])->name('alipay.transfer');
    Route::any('refund', [AlipayController::class, 'refund'])->name('alipay.refund');
    Route::any('find', [AlipayController::class, 'find'])->name('alipay.find');
    Route::any('close', [AlipayController::class, 'close'])->name('alipay.close');
    Route::any('cancel', [AlipayController::class, 'cancel'])->name('alipay.cancel');
    Route::any('return', [AlipayController::class, 'returnCallback'])->name('alipay.return');
    Route::any('notify', [AlipayController::class, 'notifyCallback'])->name('alipay.notify');
});

Route::prefix('wechat')->group(function () {
    Route::any('mp', [WechatController::class, 'mp'])->name('wechat.mp');
    Route::any('wap', [WechatController::class, 'wap'])->name('wechat.wap');
    Route::any('app', [WechatController::class, 'app'])->name('wechat.app');
    Route::any('scan', [WechatController::class, 'scan'])->name('wechat.scan');
    Route::any('mini', [WechatController::class, 'mini'])->name('wechat.mini');
    Route::any('transfer', [WechatController::class, 'transfer'])->name('wechat.transfer');
    Route::any('find', [WechatController::class, 'find'])->name('wechat.find');
    Route::any('refund', [WechatController::class, 'refund'])->name('wechat.refund');
    Route::any('close', [WechatController::class, 'close'])->name('wechat.close');
    Route::any('return', [WechatController::class, 'returnCallback'])->name('wechat.return');
    Route::any('notify', [WechatController::class, 'notifyCallback'])->name('wechat.notify');
});

Route::prefix('unipay')->group(function () {
    Route::any('web', [UnipayController::class, 'web'])->name('unipay.web');
    Route::any('wap', [UnipayController::class, 'wap'])->name('unipay.wap');
    Route::any('scan', [UnipayController::class, 'scan'])->name('unipay.scan');
    Route::any('pos', [UnipayController::class, 'pos'])->name('unipay.pos');
    Route::any('find', [UnipayController::class, 'find'])->name('unipay.find');
    Route::any('refund', [UnipayController::class, 'refund'])->name('unipay.refund');
    Route::any('cancel', [UnipayController::class, 'cancel'])->name('unipay.cancel');
    Route::any('return', [UnipayController::class, 'returnCallback'])->name('unipay.return');
    Route::any('notify', [UnipayController::class, 'notifyCallback'])->name('unipay.notify');
});
