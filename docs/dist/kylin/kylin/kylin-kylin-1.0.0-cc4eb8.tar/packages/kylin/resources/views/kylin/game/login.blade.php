<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{$title}} {{ config('app.name') }}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
        }
    </style>

</head>
<body>
<iframe id="mainiframe" src="{{$url}}" frameborder="0" scrolling="yes" height="100%" width="100%"></iframe>
<script src="https://cdn.bootcss.com/jquery/1.8.3/jquery.min.js"></script>
<script>
    function changeFrameHeight() {
        var ifm = document.getElementById("mainiframe");
        ifm.height = document.documentElement.clientHeight - 5;
    }

    window.onresize = function () {
        changeFrameHeight();
    }
    $(function () {
        changeFrameHeight();
    });
</script>
</body>
</html>
