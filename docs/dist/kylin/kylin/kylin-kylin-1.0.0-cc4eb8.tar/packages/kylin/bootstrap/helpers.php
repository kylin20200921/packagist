<?php

if (!function_exists('kylin_base_path')) {
    function kylin_base_path($path = '')
    {
        return dirname(__DIR__) . ($path != '' ? DIRECTORY_SEPARATOR . $path : '');
    }
}

if (!function_exists('kylin_app_path')) {
    function kylin_app_path($path = '')
    {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'src' . ($path != '' ? DIRECTORY_SEPARATOR . $path : '');
    }
}

if (!function_exists('kylin_config_path')) {
    function kylin_config_path($path = '')
    {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'config' . ($path != '' ? DIRECTORY_SEPARATOR . $path : '');
    }
}

if (!function_exists('kylin_database_path')) {
    function kylin_database_path($path = '')
    {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'database' . ($path != '' ? DIRECTORY_SEPARATOR . $path : '');
    }
}


if (!function_exists('kylin_lang_path')) {
    function kylin_lang_path($path = '')
    {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'lang' . ($path != '' ? DIRECTORY_SEPARATOR . $path : '');
    }
}

if (!function_exists('kylin_public_path')) {
    function kylin_public_path($path = '')
    {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'public' . ($path != '' ? DIRECTORY_SEPARATOR . $path : '');
    }
}

if (!function_exists('kylin_resource_path')) {
    function kylin_resource_path($path = '')
    {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'resources' . ($path != '' ? DIRECTORY_SEPARATOR . $path : '');
    }
}

if (!function_exists('kylin_route_path')) {
    function kylin_route_path($path = '')
    {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'routes' . ($path != '' ? DIRECTORY_SEPARATOR . $path : '');
    }
}
