<?php

return [
    'name' => env('ADMIN_TITLE', 'Kylin Admin'),
    'logo' => '<img src="/vendor/dcat-admin/images/logo.png" width="35"> &nbsp;' . env('ADMIN_TITLE', 'Kylin Admin'),
    'logo-mini' => '<img src="/vendor/dcat-admin/images/logo.png">',
    'favicon' => null,
    'default_avatar' => '@admin/images/default-avatar.jpg',
    'route' => [
        'domain' => env('ADMIN_ROUTE_DOMAIN'),
        'prefix' => env('ADMIN_ROUTE_PREFIX', 'admin'),
        'namespace' => 'Kylin\\App\\Admin\\Controllers',
        'middleware' => ['web', 'admin'],
        'enable_session_middleware' => env('ADMIN_ROUTE_SESSION', true),
    ],
    'directory' => kylin_app_path('Admin'),
    'title' => env('ADMIN_TITLE', 'Admin'),
    'assets_server' => env('ADMIN_ASSETS_SERVER'),
    'https' => env('ADMIN_HTTPS', false),
    'auth' => [
        'enable' => true,
        'controller' => Kylin\App\Admin\Controllers\AuthController::class,
        'guard' => 'admin',
        'guards' => [
            'admin' => [
                'driver' => 'session',
                'provider' => 'admin',
            ],
        ],
        'providers' => [
            'admin' => [
                'driver' => 'eloquent',
                'model' => Dcat\Admin\Models\Administrator::class,
            ],
        ],
        'remember' => true,
        'except' => [
            'auth/login',
            'auth/logout',
        ],
        'enable_session_middleware' => false,
    ],
    'grid' => [
        'grid_action_class' => Dcat\Admin\Grid\Displayers\Actions::class,
        'batch_action_class' => Dcat\Admin\Grid\Tools\BatchActions::class,
        'paginator_class' => Dcat\Admin\Grid\Tools\Paginator::class,

        'actions' => [
            'view' => Dcat\Admin\Grid\Actions\Show::class,
            'edit' => Dcat\Admin\Grid\Actions\Edit::class,
            'quick_edit' => Dcat\Admin\Grid\Actions\QuickEdit::class,
            'delete' => Dcat\Admin\Grid\Actions\Delete::class,
            'batch_delete' => Dcat\Admin\Grid\Tools\BatchDelete::class,
        ],
        'column_selector' => [
            'store' => Dcat\Admin\Grid\ColumnSelector\SessionStore::class,
            'store_params' => [
                'driver' => 'file',
            ],
        ],
    ],
    'helpers' => [
        'enable' => true,
    ],
    'permission' => [
        'enable' => true,
        'except' => [
            '/',
            'auth/login',
            'auth/logout',
            'auth/setting',
        ],
    ],
    'menu' => [
        'cache' => [
            'enable' => false,
            'store' => 'file',
        ],
        'bind_permission' => true,
        'role_bind_menu' => true,
        'permission_bind_menu' => true,
        'default_icon' => 'feather icon-circle',
    ],
    'upload' => [
        'disk' => 'admin',
        'directory' => [
            'image' => 'images',
            'file' => 'files',
        ],
    ],
    'database' => [
        'connection' => '',
        'users_table' => 'admin_users',
        'users_model' => Dcat\Admin\Models\Administrator::class,
        'roles_table' => 'admin_roles',
        'roles_model' => Dcat\Admin\Models\Role::class,
        'permissions_table' => 'admin_permissions',
        'permissions_model' => Dcat\Admin\Models\Permission::class,
        'menu_table' => 'admin_menu',
        'menu_model' => Dcat\Admin\Models\Menu::class,
        'role_users_table' => 'admin_role_users',
        'role_permissions_table' => 'admin_role_permissions',
        'role_menu_table' => 'admin_role_menu',
        'permission_menu_table' => 'admin_permission_menu',
        'settings_table' => 'admin_settings',
        'extensions_table' => 'admin_extensions',
        'extension_histories_table' => 'admin_extension_histories',
    ],
    'layout' => [
        'color' => 'kylin',
        'body_class' => [],
        'horizontal_menu' => false,
        'sidebar_collapsed' => false,
        'sidebar_style' => 'light',
        'dark_mode_switch' => false,
        'navbar_color' => '',
    ],
    'exception_handler' => Dcat\Admin\Exception\Handler::class,
    'enable_default_breadcrumb' => true,
    'extension' => [
        'dir' => kylin_base_path('extensions'),
    ],

    'multi_app' => [
        'platform' => env('PLATFORM_APP_RUN', false),
        'buyer' => env('BUYER_APP_RUN', false),
        'farm' => env('FARM_APP_RUN', false),
    ],
];
