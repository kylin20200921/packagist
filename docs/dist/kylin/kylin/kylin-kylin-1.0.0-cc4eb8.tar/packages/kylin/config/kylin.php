<?php
return [
    'route' => [
        'web' => [
            'namespace' => '\Kylin\App\Http\Controllers',
            'domain' => env('KYLIN_ROUTE_WEB_DOMAIN', env('KYLIN_ROUTE_DOMAIN')),
            'prefix' => env('KYLIN_ROUTE_WEB_PREFIX', ''),
            'as' => 'kylin.',
            'middleware' => ['web']
        ],
        'api' => [
            'namespace' => '\Kylin\App\Http\Controllers',
            'domain' => env('KYLIN_ROUTE_API_DOMAIN', env('KYLIN_ROUTE_DOMAIN')),
            'prefix' => env('KYLIN_ROUTE_API_PREFIX', 'api'),
            'as' => 'kylin.api.',
            'middleware' => ['api'],
        ],
    ],

];
