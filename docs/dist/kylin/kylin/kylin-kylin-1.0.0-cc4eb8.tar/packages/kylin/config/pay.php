<?php

declare(strict_types=1);

use Yansongda\Pay\Pay;

return [
    'alipay' => [
        'default' => [
            // 必填-支付宝分配的 app_id
            'app_id' => '2016080500175455',
            // 必填-应用私钥 字符串或路径
            // 在 https://open.alipay.com/develop/manage 《应用详情->开发设置->接口加签方式》中设置
            'app_secret_cert' => 'MIIEowIBAAKCAQEAg36GILtoLIodKOk1x5gOoFmLd2bJ6Xryd+9gq53uvloPGmTgoxTK1QoxL8f+deKbrGF4kmFOigL9c+7uo/Esia+eorWfO6cjT2mQ9gvtlCOVoqUXYOhhJ4ZoI0dLPZgzgnDa+a+z2thPy8AUidX4hju9B5xi7eD6ZGVg2dqy+I/OfpSDWMKmns2USvUA8+8tuLEvKbmNW0HIcjJED1ONEgEZHVDWRXu4fnQN0DlK8cADnZijLLo7F8YSrztd6pT6hjbZ1fllYQWShxRVW4A9rnNJKdQMUAVDqBm/Ch/WYK92hvR6/Lav+/Ed5gGqDC5dzuMHZ4s+3UN1unXMw4YP0wIDAQABAoIBAE/xBNQzezLQyMeNeH+epw2/QrXVjN1gPLbDli7ftjyNfe8a8yLSSjnYl2yoFsBOgzv6ihXcCKaJCNOJqBWNUvlmBnh/GI5on2PxFwsu10IfnCIkYiEtRZuE8By6hDivJmmf+NChjCN5LJH/db0Sk6Pv/4z3+4EJLNEKfSYU+od35+vwZp29MC2CZ2FE3JVuTqsKKk5+bSec6m0VtVOWz2lQ5cPZQSSMr8+ZTGoUK0mnzZPzdrOazZAaHfeaxxpihPBywZNJPuY4IbwQShzBLm/ErXbCZHBtJzeAAGZTb53VRilLVq8/OAgfmO2cKF2UjPYEH0lSAnmofmDPppNkdHECgYEA7AWEol6SUYXNbfZUDOjW2/6mOfp8jHnZsmp9VRptIM3MpcppUZJdNeMSyRhdIXna/lNfH5f4yUrJOjL/X7mGm6nTD0fQUmMvVTnnEb3ExEXGdbvzSSx1v+QAcxYYKP/l0JPBBvRFBKgFfb1AGM5kkAqCHNXleD6HELPru9At6IkCgYEAjp/yBGr8GjMaPkXmi7i7FrPTAtpoaHYRATtOjSTEYCxg0Ovwqv0jiEqbmlg8dFLBmnWbg39CkjKCGQqPnnleM6oTbKgqGd0RbCWAPP91QHZmDPUzT+xMxzuoa0l0Tw3bq8fLoNa0/1DqcWu7Z91YpvYpH8lDKbSbiSv/h5KbJnsCgYBm7wknXyNlFnu/Z1zEvI9oJqkMRCgpg8LjwvmiMgJB+j80VxCTmMe6Bqxcs5l6ThCqNmYX+0lvUIRuM2uYrer83JXF5kX+iG9ONhCGdkLobp3dHvk9gnxgEen4RzyGNQRfcPEQPVwUacrrSaw4pVrKTyrrtIV9aZeyOyWmJWbAMQKBgDo5u/DnyEHd6PHRUZxq7x4GjbeVeJhk0u5gyuG+R9lHZMMF/3ue2lmys7GgIhYPDvDC4JkfZAsRSaF1eUpmG/oVjdaHFKD4ajtvV9oPJEwLyf+yPp97RaD0jv41v6DidHK9nzjrTnsJCp0BMUHm0GFhD0rlvGCTVgf7CVfMl0BvAoGBAOV8NBR8XiiOT0q10FCtORAAbRvKQANWT4QsgBr5n81QUf+9c6PDlinMNY9/rrwUPGDe2gy19pAaueNd7sF8Po4/f/zhZ7C2BHk+9xYHRufCImls7PmpETL6fhgJiDQ/aRbcPyBloIK3byjjErokHHsKlypl5Xjmfvf4HSudOSdl',
            // 必填-应用公钥证书 路径
            // 设置应用私钥后，即可下载得到以下3个证书
            'app_public_cert_path' => kylin_resource_path('alipay/appCertPublicKey_2016080500175455.crt'),
            // 必填-支付宝公钥证书 路径
            'alipay_public_cert_path' => kylin_resource_path('alipay/alipayCertPublicKey_RSA2.crt'),
            // 必填-支付宝根证书 路径
            'alipay_root_cert_path' => kylin_resource_path('alipay/alipayRootCert.crt'),
            'return_url' => env('KYLIN_ALIPAY_RETURN_URL', ''),
            'notify_url' => env('KYLIN_ALIPAY_NOTIFY_URL', ''),
            // 选填-第三方应用授权token
            'app_auth_token' => '',
            // 选填-服务商模式下的服务商 id，当 mode 为 Pay::MODE_SERVICE 时使用该参数
            'service_provider_id' => '',
            // 选填-默认为正常模式。可选为： MODE_NORMAL, MODE_SANDBOX, MODE_SERVICE
            'mode' => Pay::MODE_SANDBOX,
        ],

        'platform' => [
            // 必填-支付宝分配的 app_id
            'app_id' => '2016080500175455',
            // 必填-应用私钥 字符串或路径
            // 在 https://open.alipay.com/develop/manage 《应用详情->开发设置->接口加签方式》中设置
            'app_secret_cert' => 'MIIEowIBAAKCAQEAg36GILtoLIodKOk1x5gOoFmLd2bJ6Xryd+9gq53uvloPGmTgoxTK1QoxL8f+deKbrGF4kmFOigL9c+7uo/Esia+eorWfO6cjT2mQ9gvtlCOVoqUXYOhhJ4ZoI0dLPZgzgnDa+a+z2thPy8AUidX4hju9B5xi7eD6ZGVg2dqy+I/OfpSDWMKmns2USvUA8+8tuLEvKbmNW0HIcjJED1ONEgEZHVDWRXu4fnQN0DlK8cADnZijLLo7F8YSrztd6pT6hjbZ1fllYQWShxRVW4A9rnNJKdQMUAVDqBm/Ch/WYK92hvR6/Lav+/Ed5gGqDC5dzuMHZ4s+3UN1unXMw4YP0wIDAQABAoIBAE/xBNQzezLQyMeNeH+epw2/QrXVjN1gPLbDli7ftjyNfe8a8yLSSjnYl2yoFsBOgzv6ihXcCKaJCNOJqBWNUvlmBnh/GI5on2PxFwsu10IfnCIkYiEtRZuE8By6hDivJmmf+NChjCN5LJH/db0Sk6Pv/4z3+4EJLNEKfSYU+od35+vwZp29MC2CZ2FE3JVuTqsKKk5+bSec6m0VtVOWz2lQ5cPZQSSMr8+ZTGoUK0mnzZPzdrOazZAaHfeaxxpihPBywZNJPuY4IbwQShzBLm/ErXbCZHBtJzeAAGZTb53VRilLVq8/OAgfmO2cKF2UjPYEH0lSAnmofmDPppNkdHECgYEA7AWEol6SUYXNbfZUDOjW2/6mOfp8jHnZsmp9VRptIM3MpcppUZJdNeMSyRhdIXna/lNfH5f4yUrJOjL/X7mGm6nTD0fQUmMvVTnnEb3ExEXGdbvzSSx1v+QAcxYYKP/l0JPBBvRFBKgFfb1AGM5kkAqCHNXleD6HELPru9At6IkCgYEAjp/yBGr8GjMaPkXmi7i7FrPTAtpoaHYRATtOjSTEYCxg0Ovwqv0jiEqbmlg8dFLBmnWbg39CkjKCGQqPnnleM6oTbKgqGd0RbCWAPP91QHZmDPUzT+xMxzuoa0l0Tw3bq8fLoNa0/1DqcWu7Z91YpvYpH8lDKbSbiSv/h5KbJnsCgYBm7wknXyNlFnu/Z1zEvI9oJqkMRCgpg8LjwvmiMgJB+j80VxCTmMe6Bqxcs5l6ThCqNmYX+0lvUIRuM2uYrer83JXF5kX+iG9ONhCGdkLobp3dHvk9gnxgEen4RzyGNQRfcPEQPVwUacrrSaw4pVrKTyrrtIV9aZeyOyWmJWbAMQKBgDo5u/DnyEHd6PHRUZxq7x4GjbeVeJhk0u5gyuG+R9lHZMMF/3ue2lmys7GgIhYPDvDC4JkfZAsRSaF1eUpmG/oVjdaHFKD4ajtvV9oPJEwLyf+yPp97RaD0jv41v6DidHK9nzjrTnsJCp0BMUHm0GFhD0rlvGCTVgf7CVfMl0BvAoGBAOV8NBR8XiiOT0q10FCtORAAbRvKQANWT4QsgBr5n81QUf+9c6PDlinMNY9/rrwUPGDe2gy19pAaueNd7sF8Po4/f/zhZ7C2BHk+9xYHRufCImls7PmpETL6fhgJiDQ/aRbcPyBloIK3byjjErokHHsKlypl5Xjmfvf4HSudOSdl',
            // 必填-应用公钥证书 路径
            // 设置应用私钥后，即可下载得到以下3个证书
            'app_public_cert_path' => kylin_resource_path('alipay/appCertPublicKey_2016080500175455.crt'),
            // 必填-支付宝公钥证书 路径
            'alipay_public_cert_path' => kylin_resource_path('alipay/alipayCertPublicKey_RSA2.crt'),
            // 必填-支付宝根证书 路径
            'alipay_root_cert_path' => kylin_resource_path('alipay/alipayRootCert.crt'),
            'return_url' => env('PLATFORM_ALIPAY_RETURN_URL', ''),
            'notify_url' => env('PLATFORM_ALIPAY_NOTIFY_URL', ''),
            // 选填-第三方应用授权token
            'app_auth_token' => '',
            // 选填-服务商模式下的服务商 id，当 mode 为 Pay::MODE_SERVICE 时使用该参数
            'service_provider_id' => '',
            // 选填-默认为正常模式。可选为： MODE_NORMAL, MODE_SANDBOX, MODE_SERVICE
            'mode' => Pay::MODE_SANDBOX,
        ],

        'admin' => [
            // 必填-支付宝分配的 app_id
            'app_id' => '2016080500175455',
            // 必填-应用私钥 字符串或路径
            // 在 https://open.alipay.com/develop/manage 《应用详情->开发设置->接口加签方式》中设置
            'app_secret_cert' => 'MIIEowIBAAKCAQEAg36GILtoLIodKOk1x5gOoFmLd2bJ6Xryd+9gq53uvloPGmTgoxTK1QoxL8f+deKbrGF4kmFOigL9c+7uo/Esia+eorWfO6cjT2mQ9gvtlCOVoqUXYOhhJ4ZoI0dLPZgzgnDa+a+z2thPy8AUidX4hju9B5xi7eD6ZGVg2dqy+I/OfpSDWMKmns2USvUA8+8tuLEvKbmNW0HIcjJED1ONEgEZHVDWRXu4fnQN0DlK8cADnZijLLo7F8YSrztd6pT6hjbZ1fllYQWShxRVW4A9rnNJKdQMUAVDqBm/Ch/WYK92hvR6/Lav+/Ed5gGqDC5dzuMHZ4s+3UN1unXMw4YP0wIDAQABAoIBAE/xBNQzezLQyMeNeH+epw2/QrXVjN1gPLbDli7ftjyNfe8a8yLSSjnYl2yoFsBOgzv6ihXcCKaJCNOJqBWNUvlmBnh/GI5on2PxFwsu10IfnCIkYiEtRZuE8By6hDivJmmf+NChjCN5LJH/db0Sk6Pv/4z3+4EJLNEKfSYU+od35+vwZp29MC2CZ2FE3JVuTqsKKk5+bSec6m0VtVOWz2lQ5cPZQSSMr8+ZTGoUK0mnzZPzdrOazZAaHfeaxxpihPBywZNJPuY4IbwQShzBLm/ErXbCZHBtJzeAAGZTb53VRilLVq8/OAgfmO2cKF2UjPYEH0lSAnmofmDPppNkdHECgYEA7AWEol6SUYXNbfZUDOjW2/6mOfp8jHnZsmp9VRptIM3MpcppUZJdNeMSyRhdIXna/lNfH5f4yUrJOjL/X7mGm6nTD0fQUmMvVTnnEb3ExEXGdbvzSSx1v+QAcxYYKP/l0JPBBvRFBKgFfb1AGM5kkAqCHNXleD6HELPru9At6IkCgYEAjp/yBGr8GjMaPkXmi7i7FrPTAtpoaHYRATtOjSTEYCxg0Ovwqv0jiEqbmlg8dFLBmnWbg39CkjKCGQqPnnleM6oTbKgqGd0RbCWAPP91QHZmDPUzT+xMxzuoa0l0Tw3bq8fLoNa0/1DqcWu7Z91YpvYpH8lDKbSbiSv/h5KbJnsCgYBm7wknXyNlFnu/Z1zEvI9oJqkMRCgpg8LjwvmiMgJB+j80VxCTmMe6Bqxcs5l6ThCqNmYX+0lvUIRuM2uYrer83JXF5kX+iG9ONhCGdkLobp3dHvk9gnxgEen4RzyGNQRfcPEQPVwUacrrSaw4pVrKTyrrtIV9aZeyOyWmJWbAMQKBgDo5u/DnyEHd6PHRUZxq7x4GjbeVeJhk0u5gyuG+R9lHZMMF/3ue2lmys7GgIhYPDvDC4JkfZAsRSaF1eUpmG/oVjdaHFKD4ajtvV9oPJEwLyf+yPp97RaD0jv41v6DidHK9nzjrTnsJCp0BMUHm0GFhD0rlvGCTVgf7CVfMl0BvAoGBAOV8NBR8XiiOT0q10FCtORAAbRvKQANWT4QsgBr5n81QUf+9c6PDlinMNY9/rrwUPGDe2gy19pAaueNd7sF8Po4/f/zhZ7C2BHk+9xYHRufCImls7PmpETL6fhgJiDQ/aRbcPyBloIK3byjjErokHHsKlypl5Xjmfvf4HSudOSdl',
            // 必填-应用公钥证书 路径
            // 设置应用私钥后，即可下载得到以下3个证书
            'app_public_cert_path' => kylin_resource_path('alipay/appCertPublicKey_2016080500175455.crt'),
            // 必填-支付宝公钥证书 路径
            'alipay_public_cert_path' => kylin_resource_path('alipay/alipayCertPublicKey_RSA2.crt'),
            // 必填-支付宝根证书 路径
            'alipay_root_cert_path' => kylin_resource_path('alipay/alipayRootCert.crt'),
            'return_url' => env('PLATFORM_ALIPAY_RETURN_URL', ''),
            'notify_url' => env('PLATFORM_ALIPAY_NOTIFY_URL', ''),
            // 选填-第三方应用授权token
            'app_auth_token' => '',
            // 选填-服务商模式下的服务商 id，当 mode 为 Pay::MODE_SERVICE 时使用该参数
            'service_provider_id' => '',
            // 选填-默认为正常模式。可选为： MODE_NORMAL, MODE_SANDBOX, MODE_SERVICE
            'mode' => Pay::MODE_SANDBOX,
        ],
    ],
    'wechat' => [
        'default' => [
            // 必填-商户号，服务商模式下为服务商商户号
            // 可在 https://pay.weixin.qq.com/ 账户中心->商户信息 查看
            'mch_id' => '',
            // 必填-商户秘钥
            // 即 API v3 密钥(32字节，形如md5值)，可在 账户中心->API安全 中设置
            'mch_secret_key' => '',
            // 必填-商户私钥 字符串或路径
            // 即 API证书 PRIVATE KEY，可在 账户中心->API安全->申请API证书 里获得
            // 文件名形如：apiclient_key.pem
            'mch_secret_cert' => '',
            // 必填-商户公钥证书路径
            // 即 API证书 CERTIFICATE，可在 账户中心->API安全->申请API证书 里获得
            // 文件名形如：apiclient_cert.pem
            'mch_public_cert_path' => '',
            // 必填-微信回调url
            // 不能有参数，如?号，空格等，否则会无法正确回调
            'notify_url' => 'https://yansongda.cn/wechat/notify',
            // 选填-公众号 的 app_id
            // 可在 mp.weixin.qq.com 设置与开发->基本配置->开发者ID(AppID) 查看
            'mp_app_id' => '2016082000291234',
            // 选填-小程序 的 app_id
            'mini_app_id' => '',
            // 选填-app 的 app_id
            'app_id' => '',
            // 选填-合单 app_id
            'combine_app_id' => '',
            // 选填-合单商户号
            'combine_mch_id' => '',
            // 选填-服务商模式下，子公众号 的 app_id
            'sub_mp_app_id' => '',
            // 选填-服务商模式下，子 app 的 app_id
            'sub_app_id' => '',
            // 选填-服务商模式下，子小程序 的 app_id
            'sub_mini_app_id' => '',
            // 选填-服务商模式下，子商户id
            'sub_mch_id' => '',
            // 选填-微信平台公钥证书路径, optional，强烈建议 php-fpm 模式下配置此参数
            'wechat_public_cert_path' => [
                '45F59D4DABF31918AFCEC556D5D2C6E376675D57' => __DIR__ . '/Cert/wechatPublicKey.crt',
            ],
            // 选填-默认为正常模式。可选为： MODE_NORMAL, MODE_SERVICE
            'mode' => Pay::MODE_NORMAL,
        ],
    ],
    'unipay' => [
        'default' => [
            // 必填-商户号
            'mch_id' => '777290058167151',
            // 必填-商户公私钥
            'mch_cert_path' => __DIR__ . '/Cert/unipayAppCert.pfx',
            // 必填-商户公私钥密码
            'mch_cert_password' => '000000',
            // 必填-银联公钥证书路径
            'unipay_public_cert_path' => __DIR__ . '/Cert/unipayCertPublicKey.cer',
            // 必填
            'return_url' => 'https://yansongda.cn/unipay/return',
            // 必填
            'notify_url' => 'https://yansongda.cn/unipay/notify',
        ],
    ],
    'http' => [ // optional
        'timeout' => 5.0,
        'connect_timeout' => 5.0,
        // 更多配置项请参考 [Guzzle](https://guzzle-cn.readthedocs.io/zh_CN/latest/request-options.html)
    ],
    // optional，默认 warning；日志路径为：sys_get_temp_dir().'/logs/yansongda.pay.log'
    'logger' => [
        'enable' => false,
        'file' => storage_path('logs/pay.log'),
        'level' => 'debug',
        'type' => 'single', // optional, 可选 daily.
        'max_file' => 30,
    ],
];
