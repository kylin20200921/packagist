<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdminTables extends Migration
{
    public function getConnection()
    {
        return $this->config('database.connection') ?: config('database.default');
    }

    public function config($key)
    {
        return config('admin.' . $key);
    }

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create($this->config('database.users_table'), function (Blueprint $table) {
            $table->id();
            $table->string('username')->unique()->comment('用户名');
            $table->string('password')->comment('密码');
            $table->string('name')->comment('昵称');
            $table->string('avatar')->nullable()->comment('头像');
            $table->string('email')->unique()->nullable()->comment('邮箱');
            $table->timestamp('email_verified_at')->nullable()->comment('邮箱验证');
            $table->string('phone')->nullable()->unique()->comment('手机号');
            $table->timestamp('phone_verified_at')->nullable()->comment('手机验证');
            $table->tinyInteger('status')->default(1)->comment('状态');
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create($this->config('database.roles_table'), function (Blueprint $table) {
            $table->id();
            $table->string('name')->comment('标识');
            $table->string('slug')->unique()->comment('名称');
            $table->timestamps();
        });

        Schema::create($this->config('database.permissions_table'), function (Blueprint $table) {
            $table->id();
            $table->string('name')->comment('名称');
            $table->string('slug')->unique()->comment('标识');
            $table->string('http_method')->nullable()->comment('HTTP方法');
            $table->text('http_path')->nullable()->comment('HTTP路径');
            $table->integer('order')->default(0)->comment('排序');
            $table->unsignedBigInteger('parent_id')->default(0)->comment('父节点');
            $table->timestamps();
        });

        Schema::create($this->config('database.menu_table'), function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('parent_id')->default(0)->comment('父节点');
            $table->integer('order')->default(0)->comment('排序');
            $table->string('title',)->comment('标题');
            $table->string('icon')->nullable()->comment('图标');
            $table->string('uri')->nullable()->comment('路径');
            $table->tinyInteger('show')->default(1)->comment('显示');
            $table->string('extension')->default('')->comment('扩展');
            $table->timestamps();
        });

        Schema::create($this->config('database.role_users_table'), function (Blueprint $table) {
            $table->unsignedBigInteger('role_id')->comment('角色编号');
            $table->unsignedBigInteger('user_id')->comment('用户编号');
            $table->unique(['role_id', 'user_id']);
            $table->timestamps();
        });

        Schema::create($this->config('database.role_permissions_table'), function (Blueprint $table) {
            $table->unsignedBigInteger('role_id')->comment('角色编号');
            $table->unsignedBigInteger('permission_id')->comment('权限编号');
            $table->unique(['role_id', 'permission_id']);
            $table->timestamps();
        });

        Schema::create($this->config('database.role_menu_table'), function (Blueprint $table) {
            $table->unsignedBigInteger('role_id')->comment('角色编号');
            $table->unsignedBigInteger('menu_id')->comment('菜单编号');
            $table->unique(['role_id', 'menu_id']);
            $table->timestamps();
        });

        Schema::create($this->config('database.permission_menu_table'), function (Blueprint $table) {
            $table->unsignedBigInteger('permission_id')->comment('权限编号');
            $table->unsignedBigInteger('menu_id')->comment('菜单编号');
            $table->unique(['permission_id', 'menu_id']);
            $table->timestamps();
        });

        Schema::create($this->config('database.settings_table'), function (Blueprint $table) {
            $table->string('slug')->primary()->comment('标识');
            $table->longText('value')->comment('值');
            $table->timestamps();
        });

        Schema::create($this->config('database.extensions_table'), function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique()->comment('名称');
            $table->string('version')->default('')->comment('版本');
            $table->tinyInteger('is_enabled')->default(0)->comment('是否可用');
            $table->text('options')->nullable()->comment('其他事项');
            $table->timestamps();
        });

        Schema::create($this->config('database.extension_histories_table'), function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->tinyInteger('type')->default(1);
            $table->string('version')->default(0);
            $table->text('detail')->nullable();
            $table->index('name');
            $table->timestamps();
        });

        Schema::create($this->config('database.menu_table') . '_empty', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('parent_id')->default(0)->comment('父节点');
            $table->integer('order')->default(0)->comment('排序');
            $table->string('title',)->comment('标题');
            $table->string('icon')->nullable()->comment('图标');
            $table->string('uri')->nullable()->comment('路径');
            $table->tinyInteger('show')->default(1)->comment('显示');
            $table->string('extension')->default('')->comment('扩展');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists($this->config('database.users_table'));
        Schema::dropIfExists($this->config('database.roles_table'));
        Schema::dropIfExists($this->config('database.permissions_table'));
        Schema::dropIfExists($this->config('database.menu_table'));
        Schema::dropIfExists($this->config('database.role_users_table'));
        Schema::dropIfExists($this->config('database.role_permissions_table'));
        Schema::dropIfExists($this->config('database.role_menu_table'));
        Schema::dropIfExists($this->config('database.permission_menu_table'));
        Schema::dropIfExists($this->config('database.settings_table'));
        Schema::dropIfExists($this->config('database.extensions_table'));
        Schema::dropIfExists($this->config('database.extension_histories_table'));
        Schema::dropIfExists($this->config('database.menu_table')  . '_empty');
    }
}
