<?php 
return [
    'labels' => [
        'PlatformAdmin' => 'PlatformAdmin',
        'platform-admin' => 'PlatformAdmin',
    ],
    'fields' => [
        'username' => '用户名',
        'name' => '昵称',
        'avatar' => '头像',
        'secret' => '通信密钥',
        'email' => '邮箱',
        'email_verified_at' => '邮箱验证',
        'phone' => '手机号',
        'phone_verified_at' => '手机验证',
        'password' => '密码',
        'status' => '状态',
        'remember_token' => 'remember_token',
    ],
    'options' => [
    ],
];
