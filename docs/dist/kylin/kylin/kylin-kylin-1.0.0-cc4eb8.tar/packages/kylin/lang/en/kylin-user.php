<?php 
return [
    'labels' => [
        'KylinUser' => 'KylinUser',
        'kylin-user' => 'KylinUser',
    ],
    'fields' => [
        'username' => '用户名',
        'password' => '密码',
        'secret' => '通信密钥',
        'name' => '昵称',
        'avatar' => '头像',
        'remember_token' => 'Token',
        'status' => '状态',
    ],
    'options' => [
    ],
];
