<?php

namespace Kylin\App\Http\Controllers\Payment;

use Illuminate\Http\Request;
use Kylin\App\Http\Controllers\Controller;
use Yansongda\LaravelPay\Facades\Pay;

class UnipayController extends Controller
{
    /**
     * 网页支付
     * @param Request $request
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function web(Request $request)
    {
        $order = [
            'txnTime' => $request->get('txnTime', date('YmdHis')),
            'txnAmt' => $request->get('txnAmt', '0.01'),
            'orderId' => $request->get('orderId', 'kylin' . date('YmdHis')),
        ];
        return Pay::unipay()->web($order);
    }

    /**
     * 手机支付
     * @param Request $request
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function wap(Request $request)
    {
        $order = [
            'txnTime' => $request->get('txnTime', date('YmdHis')),
            'txnAmt' => $request->get('txnAmt', '0.01'),
            'orderId' => $request->get('orderId', 'kylin' . date('YmdHis')),
        ];
        return Pay::unipay()->wap($order);
    }

    /**
     * 扫描支付
     * @param Request $request
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function scan(Request $request)
    {
        $order = [
            'txnTime' => $request->get('txnTime', date('YmdHis')),
            'txnAmt' => $request->get('txnAmt', '0.01'),
            'orderId' => $request->get('orderId', 'kylin' . date('YmdHis')),
        ];
        return Pay::unipay()->scan($order);
    }

    /**
     * 刷卡支付
     * @param Request $request
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function pos(Request $request)
    {
        $order = [
            'qrNo' => '123456789012345678',
            'txnTime' => $request->get('txnTime', date('YmdHis')),
            'txnAmt' => $request->get('txnAmt', '0.01'),
            'orderId' => $request->get('orderId', 'kylin' . date('YmdHis')),
        ];
        return Pay::unipay()->pos($order);
    }

    /**
     * 查询订单
     * @param Request $request
     * @return array|\Psr\Http\Message\MessageInterface|\Yansongda\Supports\Collection|null
     * @throws \Yansongda\Pay\Exception\ContainerException
     * @throws \Yansongda\Pay\Exception\InvalidParamsException
     * @throws \Yansongda\Pay\Exception\ServiceNotFoundException
     */
    public function find(Request $request)
    {
        $order = [
            'txnTime' => $request->get('txnTime', date('YmdHis')),
            'orderId' => $request->get('orderId', 'kylin' . date('YmdHis')),
        ];
        return Pay::unipay()->find($order);
    }

    /**
     * 退款
     * @param Request $request
     * @return array|\Psr\Http\Message\MessageInterface|\Yansongda\Supports\Collection|null
     * @throws \Yansongda\Pay\Exception\ContainerException
     * @throws \Yansongda\Pay\Exception\InvalidParamsException
     * @throws \Yansongda\Pay\Exception\ServiceNotFoundException
     */
    public function refund(Request $request)
    {
        $order = [
            'txnTime' => $request->get('txnTime', date('YmdHis')),
            'txnAmt' => $request->get('txnAmt', '0.01'),
            'orderId' => $request->get('orderId', 'kylin' . date('YmdHis')),
            'origQryId' => $request->get('origQryId', '062209121414535249018'),
        ];
        return Pay::unipay()->refund($order);
    }

    /**
     * 退款
     * @param Request $request
     * @return array|\Psr\Http\Message\MessageInterface|\Yansongda\Supports\Collection|null
     * @throws \Yansongda\Pay\Exception\ContainerException
     * @throws \Yansongda\Pay\Exception\InvalidParamsException
     * @throws \Yansongda\Pay\Exception\ServiceNotFoundException
     */
    public function cancel(Request $request)
    {
        $order = [
            'txnTime' => $request->get('txnTime', date('YmdHis')),
            'txnAmt' => $request->get('txnAmt', '0.01'),
            'orderId' => $request->get('orderId', 'kylin' . date('YmdHis')),
            'origQryId' => $request->get('origQryId', '062209121414535249018'),
        ];
        return Pay::unipay()->cancel($order);
    }

    public function returnCallback(Request $request)
    {
        try {
            $data = Pay::unipay()->callback(null, $request->all());
            return Pay::unipay()->success();
        } catch (\Exception $err) {
            return $err->getCode();
        }

    }

    public function notifyCallback(Request $request)
    {
        try {
            $data = Pay::unipay()->callback(null, $request->all());
            return Pay::unipay()->success();
        } catch (\Exception $err) {
            return $err->getCode();
        }
    }

}
