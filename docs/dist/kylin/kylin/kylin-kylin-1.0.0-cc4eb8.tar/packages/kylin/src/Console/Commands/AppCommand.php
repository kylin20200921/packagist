<?php

namespace Kylin\App\Console\Commands;

use Dcat\Admin\Support\Helper;
use Illuminate\Console\Command;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Str;
use Kylin\App\Database\Seeders\AdminTablesSeeder;
use Kylin\App\Database\Seeders\PlatformTablesSeeder;
use Kylin\App\Providers\KylinServiceProvider;

class AppCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'kylin:app {name}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '创建新的程序';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->addConfig();
        $this->initAdminDirectory();

        $this->info('Done.');
    }

    protected function addConfig()
    {
        $app = Helper::slug($namespace = $this->argument('name'));
        $this->laravel['files']->put(
            $config = kylin_config_path($app . '.php'),
            str_replace(
                ['DummyNamespace', 'DummyAppLow', 'DummyApp'],
                [$namespace, Str::lower($namespace), Str::upper($namespace)],
                $this->getStub('config')
            )
        );
        config(['admin' => include $config]);
    }

    protected function initAdminDirectory()
    {
        $this->setDirectory();

        if (is_dir($this->directory)) {
            $this->warn("{$this->directory} 目录已经存在 !");
            return;
        }

        $this->makeDir('/');
        $this->line('<info>目录已经存在:</info> ' . str_replace(base_path(), '', $this->directory));

        $this->makeDir('Controllers');
        $this->makeDir('Metrics/Examples');

        $this->createHomeController();
        $this->createAuthController();
        $this->createMetricCards();
        $this->createModels();
        $this->createViews();
        $this->createDbs();

        $this->createBootstrapFile();
        $this->createRoutesFile();
        $this->createMenuFile();

    }

    public function createHomeController()
    {
        $homeController = $this->directory . '/Controllers/HomeController.php';
        $contents = $this->getStub('HomeController');

        $this->laravel['files']->put(
            $homeController,
            str_replace(
                ['DummyNamespace', 'MetricsNamespace'],
                [$this->namespace('Controllers'), $this->namespace('Metrics\\Examples')],
                $contents
            )
        );
        $this->line('<info>HomeController file was created:</info> ' . str_replace(base_path(), '', $homeController));
    }

    public function createAuthController()
    {
        $authController = $this->directory . '/Controllers/AuthController.php';
        $contents = $this->getStub('AuthController');

        $this->laravel['files']->put(
            $authController,
            str_replace(
                ['DummyNamespace'],
                [$this->namespace('Controllers')],
                $contents
            )
        );
        $this->line('<info>AuthController file was created:</info> ' . str_replace(base_path(), '', $authController));
    }

    public function createMetricCards()
    {
        $map = [
            '/Metrics/Examples/NewUsers.php' => 'metrics/NewUsers',
            '/Metrics/Examples/NewDevices.php' => 'metrics/NewDevices',
            '/Metrics/Examples/ProductOrders.php' => 'metrics/ProductOrders',
            '/Metrics/Examples/Sessions.php' => 'metrics/Sessions',
            '/Metrics/Examples/Tickets.php' => 'metrics/Tickets',
            '/Metrics/Examples/TotalUsers.php' => 'metrics/TotalUsers',
        ];

        $namespace = $this->namespace('Metrics\\Examples');

        foreach ($map as $path => $stub) {
            $this->laravel['files']->put(
                $this->directory . $path,
                str_replace(
                    'DummyNamespace',
                    $namespace,
                    $this->getStub($stub)
                )
            );
        }
    }

    public function createViews()
    {
        $map = [
            'dashboard/title.blade.php' => 'views/dashboard',
            'helpers/scaffold.blade.php' => 'views/helpers',
            'layouts/container.blade.php' => 'views/layouts',
            'pages/login.blade.php' => 'views/login',
        ];

        $view = kylin_resource_path('views/' . Str::lower($namespace = $this->argument('name'))) . '/';
        $this->info($view. 'dashboard');

        $this->laravel['files']->makeDirectory($view. 'dashboard', 0755, true, true);
        $this->laravel['files']->makeDirectory($view. 'helpers', 0755, true, true);
        $this->laravel['files']->makeDirectory($view. 'layouts', 0755, true, true);
        $this->laravel['files']->makeDirectory($view. 'pages', 0755, true, true);

        foreach ($map as $path => $stub) {
            $this->laravel['files']->put($view . $path, str_replace(
                ['DummyNamespace', 'DummyAppLow', 'DummyApp'],
                [$namespace, Str::lower($namespace), Str::upper($namespace)],
                $this->getStub($stub)
            ));
        }
    }

    public function createModels()
    {
        $model = kylin_app_path('Models/' . $this->argument('name') . '.php');
        $namespace = $this->argument('name');
        $contents = $this->getStub('Model');

        $this->laravel['files']->put(
            $model,
            str_replace(
                ['DummyNamespace', 'DummyAppLow'],
                [$namespace, Str::lower($namespace)],
                $contents
            )
        );
        $this->line('<info>Model file was created:</info> ' . str_replace(base_path(), '', $model));
    }

    public function createDbs()
    {
        $namespace = $this->argument('name');
        $low = Str::lower($namespace);
        $migration = kylin_database_path('migrations/'. date('Y_m_d_His')."_create_${low}_tables.php");
        $contents = $this->getStub('migrations');
        $this->laravel['files']->put($migration, str_replace(
            ['DummyNamespace', 'DummyAppLow', 'DummyApp'],
            [$namespace, Str::lower($namespace), Str::upper($namespace)],
            $contents
        ));

        $seeder = kylin_database_path("seeders/${namespace}TablesSeeder.php");
        $contents = $this->getStub('seeder');
        $this->laravel['files']->put($seeder, str_replace(
            ['DummyNamespace', 'DummyAppLow', 'DummyApp'],
            [$namespace, Str::lower($namespace), Str::upper($namespace)],
            $contents
        ));
    }

    protected function createBootstrapFile()
    {
        $file = $this->directory . '/bootstrap.php';

        $contents = $this->getStub('bootstrap');
        $this->laravel['files']->put($file, str_replace(
            ['DummyAppLow'],
            [Str::lower($this->argument('name'))],
            $contents
        ));
        $this->line('<info>Bootstrap file was created:</info> ' . str_replace(base_path(), '', $file));
    }

    protected function createRoutesFile()
    {
        $file = $this->directory . '/routes.php';

        $contents = $this->getStub('routes');
        $this->laravel['files']->put($file, str_replace(
            ['DummyAppLow'],
            [Str::lower($this->argument('name'))],
            $contents
        ));
        $this->line('<info>Routes file was created:</info> ' . str_replace(base_path(), '', $file));
    }

    protected function createMenuFile()
    {
        $file = $this->directory . '/menu.php';

        $contents = $this->getStub('menu');
        $this->laravel['files']->put($file, str_replace(
            ['DummyAppLow'],
            [Str::lower($this->argument('name'))],
            $contents
        ));
        $this->line('<info>Menus file was created:</info> ' . str_replace(base_path(), '', $file));
    }

    protected function namespace($name = null)
    {
        $base = str_replace('\\Controllers', '\\', config('admin.route.namespace'));
        return trim($base, '\\') . ($name ? "\\{$name}" : '');
    }

    protected function setDirectory()
    {
        $this->directory = kylin_app_path($this->argument('name'));
    }

    protected function getStub($name)
    {
        return $this->laravel['files']->get(kylin_resource_path("stubs/$name.stub"));
    }

    protected function makeDir($path = '')
    {
        $this->laravel['files']->makeDirectory("{$this->directory}/$path", 0755, true, true);
    }
}
