<?php
return [
    [
        'id' => 'system',
        'title' => '系统管理',
        'icon' => 'fa-modx',
        'uri' => 'system',
        'parent_id' => 0,
    ],
    [
        'id' => 'system-user',
        'title' => '用户',
        'icon' => 'fa-genderless',
        'uri' => 'system/user',
        'parent_id' => 'system',
    ],

    [
        'id' => 'platform',
        'title' => '平台管理',
        'icon' => 'fa-modx',
        'uri' => 'platform',
        'parent_id' => 0,
    ],
    [
        'id' => 'platform-user',
        'title' => '用户',
        'icon' => 'fa-genderless',
        'uri' => 'platform/user',
        'parent_id' => 'platform',
    ],

    [
        'id' => 'user',
        'title' => '用户管理',
        'icon' => 'fa-modx',
        'uri' => 'user',
        'parent_id' => 0,
    ],
    [
        'id' => 'user-user',
        'title' => '用户',
        'icon' => 'fa-genderless',
        'uri' => 'user/user',
        'parent_id' => 'user',
    ],
];
