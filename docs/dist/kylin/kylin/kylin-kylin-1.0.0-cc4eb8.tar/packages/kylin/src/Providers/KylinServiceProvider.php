<?php

namespace Kylin\App\Providers;

use Illuminate\Contracts\Events\Dispatcher;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;
use Kylin\App\Kylin;

class KylinServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->mergeConfigFrom(kylin_config_path('kylin.php'), 'kylin');
        $this->mergeConfigFrom(kylin_config_path('admin.php'), 'admin');
    }

    public function boot()
    {
        $dispatcher = $this->app[Dispatcher::class];

        $this->registerCommands();
        $this->registerResources();
        $this->registerRoutes();
        $this->registerPublishing();
    }

    /**
     * 注册资源
     * @return void
     */
    protected function registerResources()
    {
        $this->loadViewsFrom(kylin_resource_path('views/kylin'), 'kylin');
        $this->loadTranslationsFrom(kylin_lang_path('kylin'), 'kylin');
        $this->loadMigrationsFrom(kylin_database_path('migrations'));
    }

    /**
     * 注册路由
     * @return void
     */
    protected function registerRoutes()
    {
        Kylin::routes();
    }

    protected function registerCommands()
    {
        if ($this->app->runningInConsole()) {
            $this->commands(Kylin::cmmands());
        }
    }

    protected function registerPublishing()
    {
        $this->publishes([
            kylin_lang_path('') => lang_path(''),
            kylin_resource_path('views/kylin') => resource_path('views/vendor/kylin'),
            kylin_public_path('') => public_path('vendor'),
        ], 'resources');

        $this->publishes([
            kylin_base_path('bootstrap/app.php') => base_path('bootstrap/app.php'),
            kylin_config_path('') => config_path(''),
        ], 'app');
    }
}
