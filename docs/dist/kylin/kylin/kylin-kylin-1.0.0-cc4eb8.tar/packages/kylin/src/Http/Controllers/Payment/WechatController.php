<?php

namespace Kylin\App\Http\Controllers\Payment;

use Illuminate\Http\Request;
use Kylin\App\Http\Controllers\Controller;
use Yansongda\LaravelPay\Facades\Pay;

class WechatController extends Controller
{
    /**
     * 公众号支付
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function mp(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'description' => $request->get('description', '麒麟教育公众号支付'),
            'amount' => [
                'total' => $request->get('total', '0.01'),
            ],
            'payer' => [
                'openid' => $request->get('openid', 'MYE42l80oelYMDE34nYD456Xoy'),
            ],
        ];
        return Pay::wechat()->mp($order);
    }

    /**
     * 手机网站支付
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function wap(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'description' => $request->get('description', '麒麟教育手机网站支付'),
            'amount' => [
                'total' => $request->get('total', '0.01'),
            ],
            'scene_info' => [
                'payer_client_ip' => $request->get('payer_client_ip', $request->getClientIp()),
                'h5_info' => [
                    'type' => $request->get('type', 'Wap'),
                ]
            ],
        ];
        return Pay::wechat()->wap($order);
    }

    /**
     * App支付
     * @param Request $request
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function app(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'description' => $request->get('description', '麒麟教育App支付'),
            'amount' => [
                'total' => $request->get('total', '0.01'),
            ],
        ];
        return Pay::wechat()->app($order);
    }

    /**
     * 扫码支付
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function scan(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'description' => $request->get('description', '麒麟教育扫码支付'),
            'amount' => [
                'total' => $request->get('total', '0.01'),
            ],
        ];
        return Pay::wechat()->scan($order);
    }


    /**
     * 小程序
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function mini(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'description' => $request->get('description', '麒麟教育小程序支付'),
            'amount' => [
                'total' => $request->get('total', '0.01'),
                'currency' => $request->get('currency', 'CNY'),
            ],
            'payer' => [
                'openid' => $request->get('openid', 'MYE42l80oelYMDE34nYD456Xoy'),
            ]
        ];
        return Pay::wechat()->mini($order);
    }

    /**
     * 转账支付
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function transfer(Request $request)
    {
        $order = [
            'out_batch_no' => $request->get('out_trade_no', time()),
            'batch_name' => $request->get('description', '麒麟教育转账支付'),
            'batch_remark' => $request->get('batch_remark', 'batch_remark'),
            'total_amount' => $request->get('total_amount', '0.01'),
            'total_num' => $request->get('total_num', '0.01'),
            'transfer_detail_list' => [
                [
                    'out_detail_no' => $request->get('out_detail_no', time()),
                    'transfer_amount' => $request->get('transfer_amount', '0.01'),
                    'transfer_remark' => $request->get('transfer_remark', 'transfer_remark'),
                    'openid' => $request->get('openid', 'MYE42l80oelYMDE34nYD456Xoy'),
                    // 'user_name' => '闫嵩达'  // 明文传参即可，sdk 会自动加密
                ],
            ],
        ];
        return Pay::wechat()->transfer($order);
    }

    /**
     * 查询支付订单
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function find(Request $request)
    {
        $order = [
            'transaction_id' => $request->get('transaction_id', '1217752501201407033233368018'),
        ];
        return Pay::wechat()->find($order);
    }

    /**
     * 退款操作
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function refund(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'out_refund_no' => $request->get('out_refund_no', time()),
            'amount' => [
                'refund' => $request->get('refund', '0.01'),
                'total' => $request->get('total', '0.01'),
                'currency' => $request->get('currency', 'CNY'),
            ],
        ];
        return Pay::wechat()->refund($order);
    }

    /**
     * 关闭普通订单操作
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function close(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
        ];
        return Pay::wechat()->close($order);
    }

    public function returnCallback(Request $request)
    {
        try {
            $data = Pay::alipay()->callback(null, $request->all());
            return Pay::alipay()->success();
        } catch (\Exception $err) {
            return $err->getCode();
        }
    }

    public function notifyCallback(Request $request)
    {
        try {
            $data = Pay::alipay()->callback(null, $request->all());
            return Pay::alipay()->success();
        } catch (\Exception $err) {
            return $err->getCode();
        }
    }
}
