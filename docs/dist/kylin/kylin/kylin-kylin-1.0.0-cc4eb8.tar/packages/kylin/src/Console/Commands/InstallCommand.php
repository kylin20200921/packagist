<?php

namespace Kylin\App\Console\Commands;

use Illuminate\Console\Command;
use Kylin\App\Database\Seeders\AdminTablesSeeder;
use Kylin\App\Database\Seeders\PlatformTablesSeeder;
use Kylin\App\Providers\KylinServiceProvider;

class InstallCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'kylin:install';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '系统初始化';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->initDatabase();
        return 0;
    }

    protected function initDatabase()
    {
        $this->call("vendor:publish", ['--provider' => KylinServiceProvider::class, '--tag' => 'resources',]);
        $this->call("vendor:publish", ['--provider' => KylinServiceProvider::class, '--tag' => 'app', '--force' => true,]);
        $this->call("admin:publish", ['--assets' => true,]);
        if (!file_exists(public_path('storage/.gitignore'))) {
            $this->call("storage:link");
        }

        $this->call('migrate');

        $adminUserModel = config('admin.database.users_model');
        if ($adminUserModel::count() == 0) {
            $this->call('db:seed', ['--class' => AdminTablesSeeder::class]);
        }
    }
}
