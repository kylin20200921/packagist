<?php

namespace Kylin\App\Http\Controllers\Payment;

use Illuminate\Http\Request;
use Kylin\App\Http\Controllers\Controller;
use Yansongda\LaravelPay\Facades\Pay;

class AlipayController extends Controller
{
    /**
     * 网页支付
     * @param Request $request
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function web(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'total_amount' => $request->get('total_amount', '0.01'),
            'subject' => $request->get('subject', '麒麟教育网页支付测试'),
            'product_code' => 'FAST_INSTANT_TRADE_PAY',
            '_config' => 'default',
            '_return_url' => 'http://api.pysxcs.com/alipay/return',
            '_notify_url' => 'http://api.pysxcs.com/alipay/notify',
        ];
        return Pay::alipay()->web($order);
    }

    /**
     * H5支付
     * @param Request $request
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function wap(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'total_amount' => $request->get('total_amount', '0.01'),
            'subject' => $request->get('subject', '麒麟教育H5支付测试'),
            'quit_url' => $request->get('quit_url', 'http://www.wangk.cn'),
            '_config' => 'default',
            '_return_url' => 'http://api.pysxcs.com/alipay/return',
            '_notify_url' => 'http://api.pysxcs.com/alipay/notify',
        ];
        return Pay::alipay()->wap($order);
    }

    /**
     * App支付
     * @param Request $request
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function app(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'total_amount' => $request->get('total_amount', '0.01'),
            'subject' => $request->get('subject', '麒麟教育APP支付测试'),
        ];
        return Pay::alipay()->app($order);
    }

    /**
     * 小程序支付
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function mini(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'total_amount' => $request->get('total_amount', '0.01'),
            'subject' => $request->get('subject', '麒麟教育小程序支付测试'),
            'buyer_id' => $request->get('buyer_id', '2088622190161234'),
        ];
        return Pay::alipay()->mini($order);
    }

    /**
     * 刷卡支付
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function pos(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'auth_code' => $request->get('auth_code', '2088622190161234'),
            'total_amount' => $request->get('total_amount', '0.01'),
            'subject' => $request->get('subject', '麒麟教育刷卡支付测试'),
        ];
        return Pay::alipay()->pos($order);
    }

    /**
     * 扫码支付
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function scan(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'total_amount' => $request->get('total_amount', '0.01'),
            'subject' => $request->get('subject', '麒麟教育扫码支付测试'),
        ];
        return Pay::alipay()->scan($order);
    }

    /**
     * 转账
     * @param Request $request
     * @return \Yansongda\Supports\Collection
     */
    public function transfer(Request $request)
    {
        $order = [
            'out_biz_no' => $request->get('out_trade_no', time()),
            'trans_amount' => $request->get('total_amount', '0.01'),
            'product_code' => 'TRANS_ACCOUNT_NO_PWD',
            'biz_scene' => 'DIRECT_TRANSFER',
            'payee_info' => [
                'identity' => 'ghdhjw7124@sandbox.com',
                'identity_type' => 'ALIPAY_LOGON_ID',
                'name' => '沙箱环境'
            ],
        ];
        return Pay::alipay()->transfer($order);
    }

    /**
     * 退款
     * @param Request $request
     * @return array|\Psr\Http\Message\MessageInterface|\Yansongda\Supports\Collection|null
     * @throws \Yansongda\Pay\Exception\ContainerException
     * @throws \Yansongda\Pay\Exception\InvalidParamsException
     * @throws \Yansongda\Pay\Exception\ServiceNotFoundException
     */
    public function refund(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
            'refund_amount' => $request->get('total_amount', '0.01'),
        ];
        return Pay::alipay()->refund($order);
    }

    /**
     * 查询订单
     * @param Request $request
     * @return array|\Psr\Http\Message\MessageInterface|\Yansongda\Supports\Collection|null
     * @throws \Yansongda\Pay\Exception\ContainerException
     * @throws \Yansongda\Pay\Exception\InvalidParamsException
     * @throws \Yansongda\Pay\Exception\ServiceNotFoundException
     */
    public function find(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
        ];
        return Pay::alipay()->find($order);
    }

    /**
     * 取消订单
     * @param Request $request
     * @return array|\Psr\Http\Message\MessageInterface|\Yansongda\Supports\Collection|null
     * @throws \Yansongda\Pay\Exception\ContainerException
     * @throws \Yansongda\Pay\Exception\InvalidParamsException
     * @throws \Yansongda\Pay\Exception\ServiceNotFoundException
     */
    public function close(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
        ];
        return Pay::alipay()->close($order);
    }

    /**
     * 查询订单
     * @param Request $request
     * @return array|\Psr\Http\Message\MessageInterface|\Yansongda\Supports\Collection|null
     * @throws \Yansongda\Pay\Exception\ContainerException
     * @throws \Yansongda\Pay\Exception\InvalidParamsException
     * @throws \Yansongda\Pay\Exception\ServiceNotFoundException
     */
    public function cancel(Request $request)
    {
        $order = [
            'out_trade_no' => $request->get('out_trade_no', time()),
        ];
        return Pay::alipay()->cancel($order);
    }


    public function returnCallback(Request $request)
    {
        try {
            $data = Pay::alipay()->callback(null, $request->all());
            return Pay::alipay()->success();
        } catch (\Exception $err) {
            return $err->getCode();
        }

    }

    public function notifyCallback(Request $request)
    {
        try {
            $data = Pay::alipay()->callback(null, $request->all());
            return Pay::alipay()->success();
        } catch (\Exception $err) {
            return $err->getCode();
        }
    }
}
