<?php

use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Route;
use Dcat\Admin\Admin;

Admin::routes();

Route::group(['prefix' => config('admin.route.prefix'), 'namespace' => config('admin.route.namespace'), 'middleware' => config('admin.route.middleware'),], function (Router $router) {
    $router->get('/', 'HomeController@index');
    $router->group(['prefix' => 'system'], function () use ($router) {

    });
    $router->group(['prefix' => 'platform'], function () use ($router) {

    });
    $router->group(['prefix' => 'user'], function () use ($router) {

    });
});

Route::group(['prefix' => config('admin.route.prefix'), 'namespace' => config('admin.route.namespace'), 'middleware' => ['api', 'admin']], function (Router $router) {
    $router->group(['prefix' => 'system'], function () use ($router) {

    });
    $router->group(['prefix' => 'platform'], function () use ($router) {

    });
    $router->group(['prefix' => 'user'], function () use ($router) {

    });
});
