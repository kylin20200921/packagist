<?php

namespace Kylin\App;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Route;

class Kylin
{
    /**
     * 获取composer.json版本信息
     * @return mixed
     */
    public static function version()
    {
        return static::config('version', '1.0.0');
    }

    /**
     * 配置所有commands
     * @return string[]
     */
    public static function cmmands(): array
    {
        return [
            Console\Commands\InstallCommand::class,
            Console\Commands\AppCommand::class,
        ];
    }

    /**
     * 配置路由信息
     * @return void
     */
    public static function routes()
    {
        $web = array_filter(config('kylin.route.web'));
        $api = array_filter(config('kylin.route.api'));
        if ((bool)config('app.debug')) {
            unset($web['domain'], $api['domain']);
        }
        Route::group($web, kylin_route_path('web.php'));
        Route::group($api, kylin_route_path('api.php'));

        require kylin_route_path('channels.php');
    }

    /**
     * 获取composer.json配置信息
     * @param $key
     * @param $default
     * @return mixed
     */
    protected static function config($key, $default = null)
    {
        return once(function () use ($key, $default) {
            $manifest = json_decode(File::get(__DIR__ . '/../composer.json'), true);
            return $manifest[$key] ?? $default;
        });
    }
}
