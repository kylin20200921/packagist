#!/bin/bash
# Author:  王康 <earl.k.wang@wangk.cn>
# BLOG:  https://blog.blog.cn

time=`date +"%Y年%m月%d日%H时%M分%S秒"`

git add -A .
git commit -m "麒麟教育项目模板，提交日期：${time}"
git tag -d 1.0.0
git tag -a 1.0.0 -m "麒麟教育项目模板，提交日期：${time}"

git push -f && git push -f --tags
